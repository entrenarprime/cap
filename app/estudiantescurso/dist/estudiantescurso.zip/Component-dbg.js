sap.ui.define(
    ["sap/fe/core/AppComponent"],
    function (Component) {
        "use strict";

        return Component.extend("estudiantescurso.Component", {
            metadata: {
                manifest: "json"
            }
        });
    }
);